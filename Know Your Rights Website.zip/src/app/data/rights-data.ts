export interface Right {
  id: number;
  title: string;
  description: string;
}

export interface Topic {
  id: string;
  title: string;
  icon: string;
  rights: Right[];
}

export const topicsData: Topic[] = [
  {
    id: 'womens-rights',
    title: "Women's Rights",
    icon: '♀',
    rights: [
      {
        id: 1,
        title: 'Equal Pay',
        description: 'Women have the right to equal pay for equal work. Employers cannot discriminate based on gender when determining compensation. This includes salary, bonuses, benefits, and other forms of payment. Any wage gap based solely on gender is illegal and can be challenged.'
      },
      {
        id: 2,
        title: 'Workplace Protection',
        description: 'Women are protected from harassment and discrimination in the workplace. This includes protection from sexual harassment, pregnancy discrimination, and hostile work environments. Employers must provide reasonable accommodations for pregnancy and nursing mothers.'
      },
      {
        id: 3,
        title: 'Reproductive Rights',
        description: 'Women have the right to make their own healthcare decisions regarding reproduction. This includes access to contraception, family planning services, and prenatal care. Healthcare providers must respect patient autonomy and confidentiality in reproductive health matters.'
      },
      {
        id: 4,
        title: 'Education Equality',
        description: 'Women have equal rights to education at all levels. Educational institutions cannot discriminate based on gender in admissions, athletics, or academic programs. Title IX protects against sex-based discrimination in education and ensures equal opportunities.'
      },
      {
        id: 5,
        title: 'Domestic Violence Protection',
        description: 'Women have the right to protection from domestic violence and abuse. This includes restraining orders, access to safe shelters, and legal support. Law enforcement must take domestic violence seriously and victims have rights to privacy and protection during legal proceedings.'
      }
    ]
  },
  {
    id: 'constitution',
    title: 'Constitutional Rights',
    icon: '⚖',
    rights: [
      {
        id: 1,
        title: 'Freedom of Speech',
        description: 'The First Amendment guarantees the right to express opinions without government censorship. This includes verbal speech, written communication, symbolic speech, and online expression. However, this does not protect speech that incites violence or creates immediate danger.'
      },
      {
        id: 2,
        title: 'Right to Privacy',
        description: 'Citizens have a constitutional right to privacy in their personal affairs. This includes protection from unreasonable searches and seizures. Law enforcement generally needs a warrant based on probable cause to search your property or person.'
      },
      {
        id: 3,
        title: 'Due Process',
        description: 'Everyone has the right to fair treatment through the judicial system. This means you cannot be deprived of life, liberty, or property without proper legal proceedings. You have the right to notice of charges and an opportunity to be heard in court.'
      },
      {
        id: 4,
        title: 'Right to Assemble',
        description: 'The First Amendment protects the right to peaceful assembly and protest. Citizens can gather publicly to express views, demonstrate, and petition the government. However, assemblies must be peaceful and may be subject to reasonable time, place, and manner restrictions.'
      },
      {
        id: 5,
        title: 'Right to Vote',
        description: 'All citizens have the constitutional right to vote without discrimination. This right cannot be denied based on race, color, sex, or previous condition of servitude. States cannot impose unreasonable barriers that prevent citizens from exercising their right to vote.'
      }
    ]
  },
  {
    id: 'road-rules',
    title: 'Road Rules',
    icon: '🚗',
    rights: [
      {
        id: 1,
        title: 'Traffic Stop Rights',
        description: 'During a traffic stop, you must provide license, registration, and insurance when requested. You have the right to remain silent beyond providing these documents. You can refuse consent to search your vehicle, though officers may search if they have probable cause.'
      },
      {
        id: 2,
        title: 'DUI Checkpoints',
        description: 'At sobriety checkpoints, you must stop when directed by law enforcement. You are required to show your license but can refuse field sobriety tests in most states. However, refusing a breathalyzer may result in automatic license suspension under implied consent laws.'
      },
      {
        id: 3,
        title: 'Right of Way Rules',
        description: 'Drivers must yield right of way according to traffic laws and signals. At unmarked intersections, yield to vehicles already in the intersection. Pedestrians in crosswalks always have right of way. Emergency vehicles with sirens require you to pull over and stop.'
      },
      {
        id: 4,
        title: 'Speed Limit Compliance',
        description: 'Posted speed limits are legally enforceable maximum speeds for ideal conditions. Drivers must reduce speed in adverse weather, heavy traffic, or poor visibility. Speed limits in school zones and construction areas carry enhanced penalties and fines.'
      },
      {
        id: 5,
        title: 'Accident Procedures',
        description: 'After an accident, you must stop and exchange information with other parties involved. Leaving the scene is illegal and can result in serious criminal charges. You should document the scene, gather witness information, and report to authorities if required by state law.'
      }
    ]
  },
  {
    id: 'workers-rights',
    title: "Workers' Rights",
    icon: '👷',
    rights: [
      {
        id: 1,
        title: 'Minimum Wage',
        description: 'Workers have the right to at least the federal or state minimum wage, whichever is higher. Employers must pay for all hours worked, including overtime at 1.5 times regular pay after 40 hours per week. Tip credits have specific rules that employers must follow.'
      },
      {
        id: 2,
        title: 'Safe Workplace',
        description: 'Every worker has the right to a safe and healthy work environment. Employers must follow OSHA regulations and provide necessary safety equipment. Workers can report unsafe conditions without fear of retaliation and refuse work that poses immediate danger to health.'
      },
      {
        id: 3,
        title: 'Break Periods',
        description: 'Many states require employers to provide rest and meal breaks during work shifts. While federal law does not mandate breaks, when given, short breaks (under 20 minutes) must be paid. Meal periods of 30 minutes or more can be unpaid if workers are completely relieved of duties.'
      },
      {
        id: 4,
        title: 'Union Rights',
        description: 'Workers have the right to join or form unions and engage in collective bargaining. Employers cannot discriminate, threaten, or retaliate against workers for union activities. Workers can discuss wages and working conditions with coworkers without employer interference.'
      },
      {
        id: 5,
        title: 'Anti-Discrimination',
        description: 'Workers are protected from discrimination based on race, color, religion, sex, national origin, age, disability, or genetic information. This applies to hiring, firing, promotions, and all employment terms. Employers must provide reasonable accommodations for disabilities and religious practices.'
      }
    ]
  },
  {
    id: 'consumer-rights',
    title: 'Consumer Rights',
    icon: '🛒',
    rights: [
      {
        id: 1,
        title: 'Right to Information',
        description: 'Consumers have the right to accurate information about products and services before purchasing. This includes pricing, ingredients, origins, and potential risks. False advertising and deceptive marketing practices are illegal and can be reported to consumer protection agencies.'
      },
      {
        id: 2,
        title: 'Return & Refund Rights',
        description: 'Many states have laws requiring retailers to post their return policies clearly. For defective products, consumers have the right to repair, replacement, or refund. Online purchases often have additional protections including cooling-off periods for returns.'
      },
      {
        id: 3,
        title: 'Privacy Protection',
        description: 'Consumers have rights regarding their personal data collection and use. Companies must disclose how they collect, use, and share your information. You have the right to opt out of data sales and request deletion of your personal information in many jurisdictions.'
      },
      {
        id: 4,
        title: 'Credit Rights',
        description: 'Consumers have the right to fair credit reporting and are entitled to free annual credit reports. You can dispute errors on credit reports and creditors must investigate disputes. Debt collectors cannot harass, threaten, or deceive you when collecting debts.'
      },
      {
        id: 5,
        title: 'Product Safety',
        description: 'All products sold must meet safety standards set by regulatory agencies. Consumers can report unsafe products to the Consumer Product Safety Commission. Manufacturers are required to recall dangerous products and notify consumers. You may be entitled to compensation for injuries from defective products.'
      }
    ]
  },
  {
    id: 'tenant-rights',
    title: 'Tenant Rights',
    icon: '🏠',
    rights: [
      {
        id: 1,
        title: 'Habitable Living Conditions',
        description: 'Tenants have the right to a safe and habitable living space. Landlords must maintain structural integrity, provide heat and hot water, ensure plumbing and electrical systems work properly, and address pest infestations. Tenants can withhold rent or repair and deduct in some cases.'
      },
      {
        id: 2,
        title: 'Privacy Rights',
        description: 'Landlords must provide proper notice (usually 24-48 hours) before entering your rental unit except in emergencies. They cannot enter without permission or harass tenants. Your home is your private space and landlords cannot use entry rights to intimidate or disturb you.'
      },
      {
        id: 3,
        title: 'Security Deposit Protection',
        description: 'Landlords must return security deposits within a specified time after move-out, typically 14-60 days depending on state law. Deductions must be itemized and documented. Interest on deposits may be required in some jurisdictions. Unfair retention can result in penalties.'
      },
      {
        id: 4,
        title: 'Anti-Discrimination',
        description: 'Housing discrimination based on race, color, religion, sex, familial status, national origin, or disability is illegal under the Fair Housing Act. Landlords cannot refuse to rent, set different terms, or provide different services based on these protected characteristics.'
      },
      {
        id: 5,
        title: 'Eviction Process',
        description: 'Landlords must follow legal eviction procedures and cannot force you out without a court order. This means no changing locks, removing belongings, or shutting off utilities. You have the right to notice and the opportunity to respond in court before eviction.'
      }
    ]
  },
  {
    id: 'student-rights',
    title: 'Student Rights',
    icon: '📚',
    rights: [
      {
        id: 1,
        title: 'Free Speech on Campus',
        description: 'Students at public institutions have First Amendment rights to free speech and expression. Schools can impose reasonable time, place, and manner restrictions but cannot censor based on viewpoint. Students can distribute literature, protest peacefully, and express opinions on campus.'
      },
      {
        id: 2,
        title: 'Privacy of Records',
        description: 'FERPA protects the privacy of student education records. Schools cannot share grades, disciplinary records, or personal information without consent. Students over 18 have the right to access their own records and request corrections to inaccurate information.'
      },
      {
        id: 3,
        title: 'Due Process in Discipline',
        description: 'Students facing suspension or expulsion are entitled to due process. This includes notice of charges, opportunity to present their side, and the right to appeal decisions. The severity of punishment should match the seriousness of the alleged misconduct.'
      },
      {
        id: 4,
        title: 'Accommodation Rights',
        description: 'Students with disabilities are entitled to reasonable accommodations under Section 504 and ADA. This includes modified assignments, extended test time, assistive technology, and accessible facilities. Schools must provide a free appropriate public education to all students.'
      },
      {
        id: 5,
        title: 'Freedom from Discrimination',
        description: 'Students are protected from discrimination and harassment based on race, color, national origin, sex, disability, or religion. Title IX protects against sex-based discrimination including sexual harassment and assault. Schools must investigate complaints and take corrective action.'
      }
    ]
  },
  {
    id: 'digital-rights',
    title: 'Digital Rights',
    icon: '💻',
    rights: [
      {
        id: 1,
        title: 'Data Privacy',
        description: 'You have the right to know what personal data companies collect about you. Many jurisdictions allow you to request access to your data, request deletion, and opt out of data sales. Companies must disclose their data practices in privacy policies.'
      },
      {
        id: 2,
        title: 'Online Free Speech',
        description: 'The First Amendment protects your speech online from government censorship but not from private platform policies. While platforms can moderate content, government actors cannot compel removal of lawful speech. You have rights against defamation and false statements about you online.'
      },
      {
        id: 3,
        title: 'Digital Security',
        description: 'You have the right to secure your digital devices and accounts. Law enforcement generally needs a warrant to search digital devices or access cloud-stored data. You can use encryption to protect your communications and data from unauthorized access.'
      },
      {
        id: 4,
        title: 'Right to Be Forgotten',
        description: 'In some jurisdictions, you can request removal of personal information from search results and websites. This right balances privacy with freedom of information and public interest. You can request outdated or irrelevant information about you be removed from online platforms.'
      },
      {
        id: 5,
        title: 'Net Neutrality',
        description: 'You have the right to access lawful internet content without interference from internet service providers. ISPs should not block, throttle, or prioritize certain content based on payment. Your internet traffic should be treated equally regardless of source or destination.'
      }
    ]
  },
  {
    id: 'healthcare-rights',
    title: 'Healthcare Rights',
    icon: '🏥',
    rights: [
      {
        id: 1,
        title: 'Informed Consent',
        description: 'You have the right to understand your medical condition and treatment options before consenting to care. Healthcare providers must explain risks, benefits, and alternatives in language you understand. You can refuse treatment and withdraw consent at any time.'
      },
      {
        id: 2,
        title: 'Medical Privacy (HIPAA)',
        description: 'Your medical information is protected under HIPAA privacy rules. Healthcare providers cannot share your health information without authorization except for treatment, payment, or healthcare operations. You can access your medical records and request corrections.'
      },
      {
        id: 3,
        title: 'Emergency Care',
        description: 'Under EMTALA, hospitals with emergency departments must provide screening and stabilizing treatment regardless of ability to pay. You cannot be turned away from emergency care due to lack of insurance or inability to pay. This applies to all hospital emergency departments.'
      },
      {
        id: 4,
        title: 'Second Opinions',
        description: 'You have the right to seek a second medical opinion before undergoing major treatment or surgery. Insurance often covers second opinions, especially for serious diagnoses. You can request copies of your medical records to share with other healthcare providers.'
      },
      {
        id: 5,
        title: 'Patient Advocates',
        description: 'You have the right to have a family member, friend, or patient advocate present during medical care. Hospitals must provide access to patient advocacy services. You can file complaints about care quality, billing issues, or violations of patient rights.'
      }
    ]
  },
  {
    id: 'immigration-rights',
    title: 'Immigration Rights',
    icon: '🌍',
    rights: [
      {
        id: 1,
        title: 'Right to Remain Silent',
        description: 'Everyone in the U.S., regardless of immigration status, has the right to remain silent when questioned by law enforcement or immigration officers. You do not have to answer questions about your immigration status or where you were born. You can refuse to sign documents you do not understand.'
      },
      {
        id: 2,
        title: 'Right to an Attorney',
        description: 'In immigration proceedings, you have the right to be represented by an attorney at your own expense. Immigration officials must provide you with a list of free or low-cost legal services. You have the right to contact your consulate for assistance.'
      },
      {
        id: 3,
        title: 'Protection from Illegal Searches',
        description: 'Immigration officers cannot enter your home without a judicial warrant signed by a judge. You can refuse entry if they only have an administrative warrant. Always ask to see a warrant and review it carefully before allowing entry.'
      },
      {
        id: 4,
        title: 'Due Process in Deportation',
        description: 'You have the right to a hearing before an immigration judge before being deported. You can present evidence, call witnesses, and appeal adverse decisions. Certain groups including asylum seekers and long-term residents have additional protections against removal.'
      },
      {
        id: 5,
        title: 'Workplace Protections',
        description: 'Regardless of immigration status, workers are protected by labor laws including minimum wage, workplace safety, and anti-discrimination laws. You can report labor violations without fear of retaliation. Employers cannot threaten deportation to prevent workers from asserting their rights.'
      }
    ]
  },
  {
    id: 'criminal-rights',
    title: 'Criminal Justice Rights',
    icon: '⚖️',
    rights: [
      {
        id: 1,
        title: 'Miranda Rights',
        description: 'Upon arrest, you must be informed of your right to remain silent and your right to an attorney. Anything you say can be used against you in court. If you cannot afford an attorney, one will be appointed for you. You can invoke these rights at any time.'
      },
      {
        id: 2,
        title: 'Right to Counsel',
        description: 'You have the constitutional right to an attorney for any criminal charge that could result in jail time. If you cannot afford one, a public defender will be appointed. Your attorney must provide competent representation and work in your best interests.'
      },
      {
        id: 3,
        title: 'Right to Speedy Trial',
        description: 'The Sixth Amendment guarantees your right to a speedy and public trial. You cannot be held indefinitely without trial. Excessive delays may result in dismissal of charges. You also have the right to know the charges against you and face your accusers.'
      },
      {
        id: 4,
        title: 'Protection from Self-Incrimination',
        description: 'The Fifth Amendment protects you from being forced to testify against yourself. You can refuse to answer questions that might incriminate you. Prosecutors cannot comment negatively on your decision to remain silent or not testify at trial.'
      },
      {
        id: 5,
        title: 'Protection from Cruel Punishment',
        description: 'The Eighth Amendment prohibits cruel and unusual punishment and excessive bail. Conditions of confinement must meet basic human needs. Prisoners retain certain constitutional rights including access to courts, medical care, and freedom from excessive force.'
      }
    ]
  },
  {
    id: 'lgbtq-rights',
    title: 'LGBTQ+ Rights',
    icon: '🏳️‍🌈',
    rights: [
      {
        id: 1,
        title: 'Employment Protection',
        description: 'Federal law prohibits employment discrimination based on sexual orientation and gender identity. This includes hiring, firing, promotions, harassment, and workplace policies. Employers must treat all employees equally regardless of LGBTQ+ status and provide equal benefits.'
      },
      {
        id: 2,
        title: 'Marriage Equality',
        description: 'Same-sex couples have the constitutional right to marry nationwide. Married same-sex couples are entitled to all federal and state benefits of marriage including tax benefits, inheritance rights, and medical decision-making authority. States cannot refuse to recognize valid same-sex marriages.'
      },
      {
        id: 3,
        title: 'Housing Rights',
        description: 'The Fair Housing Act prohibits discrimination based on sexual orientation and gender identity in housing. Landlords cannot refuse to rent, set different terms, or harass tenants based on LGBTQ+ status. This applies to rentals, sales, and mortgage lending.'
      },
      {
        id: 4,
        title: 'Healthcare Access',
        description: 'You have the right to healthcare without discrimination based on sexual orientation or gender identity. This includes access to gender-affirming care, HIV prevention and treatment, and culturally competent services. Healthcare providers cannot deny care or insurance coverage based on LGBTQ+ status.'
      },
      {
        id: 5,
        title: 'Identity Recognition',
        description: 'You have the right to be addressed by your correct name and pronouns. Many jurisdictions allow legal name and gender marker changes on identification documents. Schools and workplaces should respect your gender identity including use of appropriate facilities and dress codes.'
      }
    ]
  },
  {
    id: 'disability-rights',
    title: 'Disability Rights',
    icon: '♿',
    rights: [
      {
        id: 1,
        title: 'ADA Protection',
        description: 'The Americans with Disabilities Act prohibits discrimination in employment, public services, public accommodations, and telecommunications. Businesses and government entities must provide equal access and reasonable accommodations. Physical barriers must be removed when readily achievable.'
      },
      {
        id: 2,
        title: 'Reasonable Accommodations',
        description: 'Employers and schools must provide reasonable accommodations that enable you to perform essential functions or participate in programs. This includes modified schedules, assistive technology, accessible facilities, and adjusted policies. Accommodations should not create undue hardship on the organization.'
      },
      {
        id: 3,
        title: 'Accessible Transportation',
        description: 'Public transportation systems must be accessible to people with disabilities. This includes wheelchair-accessible buses, trains, and stations. Paratransit services must be available for those who cannot use fixed-route systems. Airlines must accommodate passengers with disabilities.'
      },
      {
        id: 4,
        title: 'Independent Living',
        description: 'You have the right to live independently in the most integrated setting appropriate. This includes access to home and community-based services rather than institutional care. Housing providers must make reasonable modifications to allow equal use and enjoyment of housing.'
      },
      {
        id: 5,
        title: 'Service Animals',
        description: 'You have the right to be accompanied by service animals in public places, housing, and on transportation. Businesses cannot exclude service animals or charge fees for them. Service animals must be allowed even in places with no-pet policies. Only dogs and miniature horses qualify as service animals.'
      }
    ]
  },
  {
    id: 'voting-rights',
    title: 'Voting Rights',
    icon: '🗳️',
    rights: [
      {
        id: 1,
        title: 'Right to Register',
        description: 'U.S. citizens 18 and older have the right to register to vote. Registration must be accessible and cannot impose unreasonable burdens. States must offer voter registration at DMVs and public assistance offices. Many states offer online registration and same-day registration.'
      },
      {
        id: 2,
        title: 'Accessible Voting',
        description: 'Polling places must be accessible to voters with disabilities. You have the right to assistance from a person of your choice or poll workers. Many jurisdictions offer alternative voting methods including mail-in ballots, early voting, and curbside voting for those who need it.'
      },
      {
        id: 3,
        title: 'Protection from Intimidation',
        description: 'You have the right to vote free from intimidation, coercion, or interference. No one can threaten you or try to influence your vote while you are at the polling place. Voter intimidation is a federal crime and can be reported to election officials or law enforcement.'
      },
      {
        id: 4,
        title: 'Provisional Ballot',
        description: 'If your eligibility is questioned at the polls, you have the right to cast a provisional ballot. This ensures your vote is counted if you are later confirmed as eligible. You must be provided information on how to verify whether your provisional ballot was counted.'
      },
      {
        id: 5,
        title: 'Language Assistance',
        description: 'Jurisdictions with significant non-English speaking populations must provide voting materials and assistance in required languages. You have the right to bring someone to help you vote if you need language assistance or help due to blindness, disability, or inability to read.'
      }
    ]
  },
  {
    id: 'privacy-rights',
    title: 'Privacy Rights',
    icon: '🔒',
    rights: [
      {
        id: 1,
        title: 'Fourth Amendment Protection',
        description: 'The Fourth Amendment protects against unreasonable searches and seizures. Law enforcement needs a warrant based on probable cause to search your home, car, or person in most circumstances. Evidence obtained through illegal searches can be excluded from criminal trials.'
      },
      {
        id: 2,
        title: 'Financial Privacy',
        description: 'Your financial records are protected by federal privacy laws. Banks cannot share your account information without your consent except in limited circumstances. You have the right to opt out of information sharing between affiliated financial institutions and to dispute inaccuracies in your records.'
      },
      {
        id: 3,
        title: 'Communication Privacy',
        description: 'Federal wiretap laws protect the privacy of your phone calls, emails, and text messages. Law enforcement generally needs a warrant to intercept your communications. Service providers cannot disclose the contents of your communications without legal authority or your consent.'
      },
      {
        id: 4,
        title: 'Genetic Privacy',
        description: 'The Genetic Information Nondiscrimination Act protects against discrimination based on genetic information in health insurance and employment. Employers and insurers cannot request genetic testing or use genetic information in decisions. You control who has access to your genetic data.'
      },
      {
        id: 5,
        title: 'Right Against Surveillance',
        description: 'You have rights against unwarranted government surveillance. Bulk data collection programs must comply with constitutional limitations. Private surveillance in certain areas like bathrooms or changing rooms is illegal. You can request information about government surveillance through FOIA requests.'
      }
    ]
  },
  {
    id: 'parental-rights',
    title: 'Parental Rights',
    icon: '👨‍👩‍👧‍👦',
    rights: [
      {
        id: 1,
        title: 'Educational Decisions',
        description: 'Parents have the fundamental right to direct the education and upbringing of their children. This includes choosing between public, private, or home schooling. You can access your child\'s educational records and participate in decisions about special education services and accommodations.'
      },
      {
        id: 2,
        title: 'Medical Consent',
        description: 'Parents have the right to make medical decisions for their minor children. This includes consenting to or refusing medical treatment except in emergencies or court-ordered situations. You must be informed of your child\'s medical condition and treatment options in understandable terms.'
      },
      {
        id: 3,
        title: 'Custody and Visitation',
        description: 'Both parents generally have equal rights to custody and visitation unless a court orders otherwise. Courts must consider the best interests of the child when making custody decisions. Non-custodial parents typically have rights to visitation, access to school records, and participation in major decisions.'
      },
      {
        id: 4,
        title: 'Child Protective Services',
        description: 'If CPS investigates your family, you have rights including the right to know the allegations, to legal representation, and to appeal findings. CPS generally needs a court order to remove children from your home except in emergencies. You have the right to a hearing to challenge removal.'
      },
      {
        id: 5,
        title: 'Religious Upbringing',
        description: 'Parents have the constitutional right to raise their children according to their religious beliefs. This includes teaching religious values, attending religious services, and choosing religious education. Schools must accommodate religious practices and cannot promote or inhibit religion.'
      }
    ]
  },
  {
    id: 'environmental-rights',
    title: 'Environmental Rights',
    icon: '🌱',
    rights: [
      {
        id: 1,
        title: 'Clean Air and Water',
        description: 'Citizens have the right to clean air and water under federal environmental laws. The EPA enforces standards for air quality, drinking water safety, and pollution control. You can report environmental violations and participate in public hearings on environmental decisions affecting your community.'
      },
      {
        id: 2,
        title: 'Right to Know',
        description: 'Communities have the right to know about toxic chemicals and pollutants in their area. The Toxics Release Inventory provides public information about chemical releases. Employers must inform workers about hazardous substances they may encounter and provide material safety data sheets.'
      },
      {
        id: 3,
        title: 'Environmental Justice',
        description: 'All communities have the right to equal protection from environmental hazards regardless of race or income. Agencies must consider disproportionate environmental impacts on minority and low-income populations. You can challenge decisions that create environmental inequities in your community.'
      },
      {
        id: 4,
        title: 'Public Participation',
        description: 'Citizens have the right to participate in environmental decision-making processes. This includes commenting on proposed regulations, attending public hearings, and accessing environmental impact assessments. Agencies must consider public input before making major environmental decisions.'
      },
      {
        id: 5,
        title: 'Protection from Nuisances',
        description: 'Property owners have rights against environmental nuisances that substantially interfere with use and enjoyment of property. This includes excessive noise, odors, air pollution, or water contamination. You can seek legal remedies through nuisance lawsuits or file complaints with environmental agencies.'
      }
    ]
  },
  {
    id: 'animal-rights',
    title: 'Animal Welfare & Rights',
    icon: '🐾',
    rights: [
      {
        id: 1,
        title: 'Pet Ownership Rights',
        description: 'Pet owners have the right to keep companion animals in most housing situations. The Fair Housing Act requires reasonable accommodation for assistance animals. Many states protect pet ownership rights and prohibit breed-specific legislation. You can pursue legal action if your pet is wrongfully injured or killed.'
      },
      {
        id: 2,
        title: 'Anti-Cruelty Laws',
        description: 'All states have anti-cruelty laws protecting animals from abuse and neglect. You can report animal cruelty to law enforcement or animal control. Animal abusers can face criminal charges including felonies for severe cases. Animals have legal protection from torture, abandonment, and inhumane treatment.'
      },
      {
        id: 3,
        title: 'Veterinary Care Standards',
        description: 'Animals in your care are entitled to necessary veterinary treatment. Veterinarians must follow professional standards and obtain informed consent for procedures. You have the right to your pet\'s medical records and to seek second opinions. Malpractice claims are available for veterinary negligence.'
      },
      {
        id: 4,
        title: 'Service Animal Access',
        description: 'Service animals have the legal right to accompany their handlers in public places, housing, and transportation. Businesses cannot deny access, charge fees, or impose special restrictions on service animals. Handlers are protected from discrimination and have recourse if access is denied.'
      },
      {
        id: 5,
        title: 'Wildlife Protection',
        description: 'Federal laws protect endangered species and their habitats. Citizens can report violations of wildlife protection laws to appropriate authorities. Public participation is allowed in decisions affecting protected species. Penalties exist for harming, harassing, or trafficking protected wildlife.'
      }
    ]
  }
];