import { useState } from 'react';
import { AnimatePresence } from 'motion/react';
import { LandingPage } from './components/LandingPage';
import { FlashCardStack } from './components/FlashCardStack';
import { topicsData, Topic } from './data/rights-data';

export default function App() {
  const [selectedTopic, setSelectedTopic] = useState<Topic | null>(null);

  const handleTopicSelect = (topic: Topic) => {
    setSelectedTopic(topic);
  };

  const handleBack = () => {
    setSelectedTopic(null);
  };

  return (
    <div className="min-h-screen">
      <AnimatePresence mode="wait">
        {!selectedTopic ? (
          <LandingPage
            key="landing"
            topics={topicsData}
            onTopicSelect={handleTopicSelect}
          />
        ) : (
          <FlashCardStack
            key="flashcards"
            rights={selectedTopic.rights}
            topicTitle={selectedTopic.title}
            onBack={handleBack}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
