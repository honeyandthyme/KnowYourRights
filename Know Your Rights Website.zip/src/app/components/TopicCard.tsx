import { motion } from 'motion/react';

interface TopicCardProps {
  title: string;
  icon: string;
  onClick: () => void;
}

export function TopicCard({ title, icon, onClick }: TopicCardProps) {
  return (
    <motion.button
      onClick={onClick}
      className="relative bg-[#f4ebe1] border-4 border-[#3a3226] p-8 shadow-[8px_8px_0px_0px_rgba(58,50,38,1)] hover:shadow-[4px_4px_0px_0px_rgba(58,50,38,1)] hover:translate-x-1 hover:translate-y-1 transition-all duration-200"
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
    >
      <div className="text-6xl mb-4">{icon}</div>
      <h3 className="text-xl text-[#3a3226] font-['Special_Elite'] uppercase tracking-wider">
        {title}
      </h3>
      <div className="mt-4 text-sm text-[#6b5d4f] font-['Courier_Prime']">
        Click to learn →
      </div>
    </motion.button>
  );
}
