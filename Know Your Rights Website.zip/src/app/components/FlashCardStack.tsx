import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { FlashCard } from './FlashCard';
import { Right } from '../data/rights-data';
import { ArrowLeft } from 'lucide-react';

interface FlashCardStackProps {
  rights: Right[];
  topicTitle: string;
  onBack: () => void;
}

export function FlashCardStack({ rights, topicTitle, onBack }: FlashCardStackProps) {
  const [cards, setCards] = useState(rights);

  const handleSwipe = () => {
    setCards((prevCards) => {
      const newCards = [...prevCards];
      const swipedCard = newCards.shift();
      if (swipedCard) {
        newCards.push(swipedCard);
      }
      return newCards;
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen bg-[#e8dcc8] p-4 md:p-8"
    >
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <motion.button
            onClick={onBack}
            className="flex items-center gap-2 text-[#3a3226] font-['Courier_Prime'] mb-6 hover:translate-x-[-4px] transition-transform"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <ArrowLeft className="w-6 h-6" />
            <span className="text-lg">Back to Topics</span>
          </motion.button>

          <h2 className="text-3xl md:text-4xl font-['Special_Elite'] text-[#3a3226] uppercase tracking-wider border-4 border-[#3a3226] bg-[#f4ebe1] p-4 shadow-[6px_6px_0px_0px_rgba(58,50,38,1)]">
            {topicTitle}
          </h2>
        </div>

        {/* Card Stack */}
        <div className="relative min-h-[450px] md:min-h-[500px]">
          <AnimatePresence mode="popLayout">
            {cards.map((right, index) => (
              <FlashCard
                key={`${right.id}-${index}`}
                right={right}
                index={index}
                totalCards={cards.length}
                onSwipe={handleSwipe}
              />
            ))}
          </AnimatePresence>
        </div>

        {/* Instructions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="mt-8 text-center"
        >
          <div className="bg-[#f4ebe1] border-2 border-[#3a3226] p-4 inline-block">
            <p className="font-['Courier_Prime'] text-[#3a3226]">
              💡 <span className="font-bold">Tip:</span> Drag cards left or right to cycle through your rights
            </p>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
}
