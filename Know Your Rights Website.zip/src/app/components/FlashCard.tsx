import { motion, useMotionValue, useTransform, PanInfo } from 'motion/react';
import { Right } from '../data/rights-data';

interface FlashCardProps {
  right: Right;
  index: number;
  totalCards: number;
  onSwipe: () => void;
}

export function FlashCard({ right, index, totalCards, onSwipe }: FlashCardProps) {
  const x = useMotionValue(0);
  const rotate = useTransform(x, [-200, 200], [-15, 15]);
  const opacity = useTransform(x, [-200, -100, 0, 100, 200], [0.5, 1, 1, 1, 0.5]);

  const handleDragEnd = (_event: MouseEvent | TouchEvent | PointerEvent, info: PanInfo) => {
    if (Math.abs(info.offset.x) > 100) {
      onSwipe();
    }
  };

  // Calculate card position in stack
  const stackOffset = Math.min(index * 8, 24);
  const stackScale = 1 - Math.min(index * 0.03, 0.09);

  return (
    <motion.div
      style={{
        x,
        rotate,
        opacity,
        zIndex: totalCards - index,
      }}
      drag={index === 0 ? "x" : false}
      dragConstraints={{ left: 0, right: 0 }}
      onDragEnd={handleDragEnd}
      animate={{
        scale: index === 0 ? 1 : stackScale,
        y: index === 0 ? 0 : stackOffset,
      }}
      transition={{
        type: 'spring',
        stiffness: 300,
        damping: 30,
      }}
      className="absolute top-0 left-0 w-full cursor-grab active:cursor-grabbing"
    >
      <div className="bg-[#faf6f1] border-4 border-[#3a3226] p-8 shadow-[12px_12px_0px_0px_rgba(58,50,38,1)] min-h-[400px] flex flex-col">
        {/* Card number indicator */}
        <div className="flex justify-between items-start mb-6">
          <div className="text-sm font-['Courier_Prime'] text-[#6b5d4f]">
            Card {right.id} of {totalCards}
          </div>
          <div className="text-2xl">📋</div>
        </div>

        {/* Title */}
        <h3 className="text-2xl md:text-3xl font-['Special_Elite'] text-[#3a3226] mb-6 uppercase tracking-wide border-b-2 border-[#3a3226] pb-3">
          {right.title}
        </h3>

        {/* Description */}
        <p className="font-['Courier_Prime'] text-base md:text-lg leading-relaxed text-[#3a3226] flex-1">
          {right.description}
        </p>

        {/* Swipe hint for first card */}
        {index === 0 && (
          <motion.div
            className="mt-6 text-center text-sm font-['Courier_Prime'] text-[#6b5d4f]"
            animate={{ opacity: [0.5, 1, 0.5] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            ← Swipe to see next card →
          </motion.div>
        )}
      </div>
    </motion.div>
  );
}
