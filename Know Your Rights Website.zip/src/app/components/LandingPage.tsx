import { motion } from 'motion/react';
import { TopicCard } from './TopicCard';
import { Topic } from '../data/rights-data';

interface LandingPageProps {
  topics: Topic[];
  onTopicSelect: (topic: Topic) => void;
}

export function LandingPage({ topics, onTopicSelect }: LandingPageProps) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen bg-[#e8dcc8] p-4 md:p-8"
    >
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ y: -50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-center mb-12 md:mb-16"
        >
          <div className="inline-block bg-[#3a3226] text-[#f4ebe1] px-6 py-3 mb-6 border-4 border-[#3a3226] shadow-[8px_8px_0px_0px_rgba(107,93,79,1)]">
            <h1 className="text-4xl md:text-6xl font-['Special_Elite'] uppercase tracking-wider">
              Know Your Rights
            </h1>
          </div>
          
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="text-lg md:text-xl font-['Courier_Prime'] text-[#3a3226] max-w-2xl mx-auto leading-relaxed"
          >
            Understanding your rights is the first step to protecting them.
            <br />
            Select a topic below to begin learning.
          </motion.p>
        </motion.div>

        {/* Topic Grid */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-10"
        >
          {topics.map((topic, index) => (
            <motion.div
              key={topic.id}
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 * index }}
            >
              <TopicCard
                title={topic.title}
                icon={topic.icon}
                onClick={() => onTopicSelect(topic)}
              />
            </motion.div>
          ))}
        </motion.div>

        {/* Footer */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="mt-16 text-center"
        >
          <div className="border-t-2 border-[#3a3226] pt-8">
            <p className="font-['Courier_Prime'] text-[#6b5d4f] text-sm">
              Information is power. Stay informed, stay protected.
            </p>
            <p className="font-['Courier_Prime'] text-[#6b5d4f] text-xs mt-2">
              © 2026 Know Your Rights • Educational Resource
            </p>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
}
