
  # Know Your Rights Website

  This is a code bundle for Know Your Rights Website. The original project is available at https://www.figma.com/design/Qcs0IgJgkkt0SABUmUg2Uv/Know-Your-Rights-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  